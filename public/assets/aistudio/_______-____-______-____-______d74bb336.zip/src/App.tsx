import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import { motion, AnimatePresence } from 'motion/react';
import { Star, Lock, Sparkles, BookOpen, Volume2, X, ShoppingBag, CheckCircle2 } from 'lucide-react';
import { EmotionType, StageId, BraveryStar, ParentSettings, CompanionProfile } from './types';
import { DIALOGUES, formatDialogue } from './data/dialogue';
import { sound } from './utils/audio';
import { haptics } from './utils/haptics';
import { Storage } from './utils/storage';

import { LuluMood } from './components/LuluCharacter';
import { CompanionCharacter, COMPANIONS_DATA } from './components/CompanionCharacter';
import { CompanionSelectionModal } from './components/CompanionSelectionModal';
import { SpeechSpeakerButton } from './components/SpeechSpeakerButton';
import { BraveryBookModal } from './components/BraveryBookModal';
import { ParentModal } from './components/ParentModal';
import { SleepScreen } from './components/SleepScreen';
import { PWAInstallButton } from './components/PWAInstallButton';
import { StartScreen } from './components/StartScreen';
import { AudioTestModal } from './components/AudioTestModal';
import { VirtualShopModal } from './components/VirtualShopModal'; 

import { StageMagicWords } from './components/stages/StageMagicWords';
import { StageHourglass } from './components/stages/StageHourglass';
import { StagePlanB } from './components/stages/StagePlanB';
import { StageBalloonBreathing } from './components/stages/StageBalloonBreathing';
import { StageWhenICry } from './components/stages/StageWhenICry';
// استيراد اللعبتين الجديدتين
import { StageMemoryGame } from './components/stages/StageMemoryGame'; 
import { StageZenBubbles } from './components/stages/StageZenBubbles'; 

const EMOTIONS_CONFIG: Array<{ type: EmotionType; label: string; emoji: string; color: string; ring: string }> = [
  { type: 'happy', label: 'سعيد', emoji: '😄', color: 'bg-emerald-100 text-emerald-900 border-emerald-300', ring: 'ring-emerald-400' },
  { type: 'sad', label: 'حزين', emoji: '😢', color: 'bg-sky-100 text-sky-900 border-sky-300', ring: 'ring-sky-400' },
  { type: 'angry', label: 'غاضب', emoji: '😠', color: 'bg-rose-100 text-rose-900 border-rose-300', ring: 'ring-rose-400' },
  { type: 'afraid', label: 'خائف', emoji: '😨', color: 'bg-purple-100 text-purple-900 border-purple-300', ring: 'ring-purple-400' },
];

const STAGES_LIST: Array<{
  id: StageId;
  title: string;
  tagline: string;
  emoji: string;
  bg: string;
  border: string;
}> = [
  {
    id: 'memory_game',
    title: 'لعبة الذاكرة',
    tagline: 'تحدي التركيز',
    emoji: '🃏',
    bg: 'from-indigo-400 to-purple-500 text-white',
    border: 'border-indigo-300',
  },
  {
    id: 'zen_bubbles',
    title: 'فقاعات الهدوء',
    tagline: 'للاسترخاء والتأمل',
    emoji: '🫧',
    bg: 'from-sky-300 to-blue-400 text-sky-900',
    border: 'border-white',
  },
  {
    id: 'magic_words',
    title: 'الكلمات السحرية',
    tagline: 'كيف نطلب بذكاء؟',
    emoji: '🪄',
    bg: 'from-amber-400 to-orange-400 text-amber-950',
    border: 'border-amber-300',
  },
  {
    id: 'hourglass',
    title: 'وقت الانتظار',
    tagline: 'لنتدرب على الصبر',
    emoji: '⏳',
    bg: 'from-sky-400 to-blue-500 text-white',
    border: 'border-sky-300',
  },
  {
    id: 'plan_b',
    title: 'الخطة البديلة',
    tagline: 'ماذا لو تغيرت الخطة؟',
    emoji: '🧭',
    bg: 'from-emerald-400 to-teal-500 text-white',
    border: 'border-emerald-300',
  },
  {
    id: 'rose_breathing',
    title: 'تنفس البالون',
    tagline: 'لنهدئ الغضب الشديد',
    emoji: '🎈',
    bg: 'from-rose-400 to-pink-500 text-white',
    border: 'border-rose-300',
  },
  {
    id: 'when_i_cry',
    title: 'عندما أبكي',
    tagline: 'الدموع تتحدث أحياناً',
    emoji: '🫂',
    bg: 'from-violet-400 to-purple-500 text-white',
    border: 'border-violet-300',
  },
];

export default function App() {
  const [hasStarted, setHasStarted] = useState(false);
  const [activeStage, setActiveStage] = useState<StageId | null>(null);
  const [selectedEmotion, setSelectedEmotion] = useState<EmotionType | null>(null);
  const [stars, setStars] = useState<BraveryStar[]>([]);
  const [completedStages, setCompletedStages] = useState<StageId[]>(() => Storage.getCompletedStageIds());
  const [settings, setSettings] = useState<ParentSettings>(Storage.getSettings());
  
  const [luluMood, setLuluMood] = useState<LuluMood>('idle');
  const [homePrompt, setHomePrompt] = useState<string>(DIALOGUES.welcome.greeting);

  const [companionProfile, setCompanionProfile] = useState<CompanionProfile>(() => Storage.getCompanionProfile());
  const [isCompanionModalOpen, setIsCompanionModalOpen] = useState(false);
  const [hasChosenInitial, setHasChosenInitial] = useState(() => Storage.hasChosenInitialCompanion());
  const [friendUnlockBanner, setFriendUnlockBanner] = useState<string | null>(null);
  
  const companionDef = COMPANIONS_DATA[companionProfile.type] || COMPANIONS_DATA.lion;

  const [isBookOpen, setIsBookOpen] = useState(false);
  const [isShopOpen, setIsShopOpen] = useState(false);
  const [isParentOpen, setIsParentOpen] = useState(false);
  const [isAudioTestOpen, setIsAudioTestOpen] = useState(false);
  const [isSleepMode, setIsSleepMode] = useState(false);

  const [parentHoldProgress, setParentHoldProgress] = useState(0);
  const parentHoldTimerRef = useRef<number | null>(null);
  const parentHoldStartRef = useRef<number | null>(null);

  useEffect(() => {
    setStars(Storage.getStars());
    setCompletedStages(Storage.getCompletedStageIds());
    const interval = setInterval(() => {
      const secs = Storage.incrementPlaySeconds(5);
      const limitSecs = settings.dailyLimitMinutes * 60;
      if (settings.dailyLimitMinutes < 999 && secs >= limitSecs) {
        setIsSleepMode(true);
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [settings.dailyLimitMinutes]);

  useEffect(() => {
    if (hasStarted && hasChosenInitial && !activeStage && !isSleepMode) {
      const text = formatDialogue(homePrompt, companionProfile.name, companionDef.title);
      sound.speak(text);
    }
  }, [hasStarted, hasChosenInitial, activeStage, isSleepMode]);

  const handleSelectEmotion = (emotion: EmotionType) => {
    sound.playTap();
    haptics.tap();
    setSelectedEmotion(emotion);
    Storage.logEmotion(emotion);

    const rawFeedback = DIALOGUES.welcome.afterEmotion[emotion];
    const feedback = formatDialogue(rawFeedback, companionProfile.name, companionDef.title);
    setHomePrompt(feedback);

    if (emotion === 'happy') setLuluMood('happy');
    else if (emotion === 'sad') setLuluMood('comforting');
    else if (emotion === 'angry') setLuluMood('idle');
    else setLuluMood('talking');

    sound.speak(feedback, () => {
      setTimeout(() => {
        setLuluMood('idle');
      }, 2000);
    });
  };

  const handleStartStage = (stageId: StageId) => {
    sound.playTap();
    haptics.tap();
    setActiveStage(stageId);
  };

  const refreshProgress = () => setCompletedStages(Storage.getCompletedStageIds());

  const handleEarnStar = (sticker: string, note: string) => {
    const stageInfo = STAGES_LIST.find(s => s.id === activeStage);
    const newStar = Storage.addStar({
      stageId: activeStage || 'magic_words',
      stageTitle: stageInfo ? stageInfo.title : `مرحلة ${companionProfile.name}`,
      sticker,
      note,
    });
    
    const updatedStars = [newStar, ...stars];
    setStars(updatedStars);
    refreshProgress();

    const currentCoins = companionProfile.coins || 0;
    const updatedProfWithCoins = Storage.saveCompanionProfile({
      coins: currentCoins + 10
    });
    setCompanionProfile(updatedProfWithCoins);

    const prevUnlockedCount = companionProfile.unlockedTypes.length;
    const finalProf = Storage.checkAndUpdateStarUnlocks(updatedStars.length);
    if (finalProf.unlockedTypes.length > prevUnlockedCount) {
      setCompanionProfile(finalProf);
      setFriendUnlockBanner('صديق جديد متاح الآن!');
      sound.playSuccessChime();
      confetti({ particleCount: 90, spread: 80, origin: { y: 0.6 } });
      sound.speak('لقد انضم إلينا صديق جديد!');
    }
  };

  const handleParentLockPointerDown = () => {
    parentHoldStartRef.current = Date.now();
    sound.playTap();
    haptics.tap();
    
    const checkLoop = () => {
      if (!parentHoldStartRef.current) return;
      const elapsed = Date.now() - parentHoldStartRef.current;
      const progress = Math.min(1, elapsed / 3000);
      setParentHoldProgress(progress);
      
      if (progress >= 1) {
        setParentHoldProgress(0);
        setIsParentOpen(true);
        sound.playSuccessChime();
        haptics.success();
      } else {
        parentHoldTimerRef.current = requestAnimationFrame(checkLoop);
      }
    };
    parentHoldTimerRef.current = requestAnimationFrame(checkLoop);
  };

  const handleParentLockPointerUp = () => {
    parentHoldStartRef.current = null;
    if (parentHoldTimerRef.current) {
      cancelAnimationFrame(parentHoldTimerRef.current);
    }
    setParentHoldProgress(0);
  };

  const updateProfileDisplay = () => {
    setCompanionProfile(Storage.getCompanionProfile());
  };

  if (!hasStarted) return <StartScreen onStart={() => setHasStarted(true)} />;
  
  if (!hasChosenInitial) {
    return (
      <CompanionSelectionModal
        isOpen={true}
        isInitialSetup={true}
        initialType={companionProfile.type}
        initialName={companionProfile.name}
        onCompanionSelected={(newProf) => {
          setCompanionProfile(newProf);
          setHasChosenInitial(true);
          const greeting = formatDialogue(DIALOGUES.welcome.greeting, newProf.name, COMPANIONS_DATA[newProf.type].title);
          setHomePrompt(greeting);
          sound.speak(greeting);
        }}
      />
    );
  }

  if (isSleepMode) {
    return <SleepScreen onParentUnlock={() => { setIsSleepMode(false); setIsParentOpen(true); }} />;
  }

  if (activeStage === 'memory_game') {
    return <StageMemoryGame onBack={() => { sound.playTap(); haptics.tap(); updateProfileDisplay(); refreshProgress(); setActiveStage(null); }} />;
  }
  if (activeStage === 'zen_bubbles') {
    return <StageZenBubbles onBack={() => { sound.playTap(); haptics.tap(); updateProfileDisplay(); refreshProgress(); setActiveStage(null); }} />;
  }
  if (activeStage === 'magic_words') {
    return <StageMagicWords onBack={() => { sound.playTap(); haptics.tap(); refreshProgress(); setActiveStage(null); }} onEarnStar={handleEarnStar} />;
  }
  if (activeStage === 'hourglass') {
    return <StageHourglass onBack={() => { sound.playTap(); haptics.tap(); refreshProgress(); setActiveStage(null); }} onEarnStar={handleEarnStar} />;
  }
  if (activeStage === 'plan_b') {
    return <StagePlanB onBack={() => { sound.playTap(); haptics.tap(); refreshProgress(); setActiveStage(null); }} onEarnStar={handleEarnStar} />;
  }
  if (activeStage === 'rose_breathing') {
    return <StageBalloonBreathing onBack={() => { sound.playTap(); haptics.tap(); refreshProgress(); setActiveStage(null); }} onEarnStar={handleEarnStar} />;
  }
  if (activeStage === 'when_i_cry') {
    return <StageWhenICry onBack={() => { sound.playTap(); haptics.tap(); refreshProgress(); setActiveStage(null); }} onEarnStar={handleEarnStar} />;
  }

  return (
    <div className="relative min-h-screen w-full flex flex-col justify-between p-4 md:p-6 bg-gradient-to-b from-amber-100 via-amber-50 to-emerald-100 overflow-x-hidden select-none">
      <div className="absolute inset-0 pointer-events-none opacity-20 overflow-hidden">
        <div className="absolute -top-10 -left-10 w-64 h-64 rounded-full bg-emerald-400 blur-3xl" />
        <div className="absolute top-1/2 -right-10 w-72 h-72 rounded-full bg-amber-400 blur-3xl" />
        <div className="absolute bottom-0 left-1/4 w-80 h-80 rounded-full bg-lime-300 blur-3xl" />
      </div>

      <header className="relative z-20 flex items-center justify-between gap-2 max-w-xl mx-auto w-full">
        <div className="flex gap-2">
          <button
            onClick={() => {
              sound.playTap();
              haptics.tap();
              setIsBookOpen(true);
            }}
            className="flex items-center gap-2 px-3 md:px-4 py-2 rounded-full bg-white/95 hover:bg-white text-amber-950 font-black shadow-md border-2 border-amber-300 touch-manipulation cursor-pointer transition transform active:scale-95"
          >
            <Star className="w-5 h-5 text-amber-500 fill-amber-400 animate-pulse" />
            <span className="text-base font-black">{stars.length}</span>
          </button>
          
          <button
            onClick={() => {
              sound.playTap();
              haptics.tap();
              setIsShopOpen(true);
            }}
            className="flex items-center gap-1.5 px-3 md:px-4 py-2 rounded-full bg-white/95 hover:bg-white text-emerald-950 font-black shadow-md border-2 border-emerald-300 touch-manipulation cursor-pointer transition transform active:scale-95"
          >
            <ShoppingBag className="w-5 h-5 text-emerald-500" />
            <span className="text-base font-black">{companionProfile.coins || 0}</span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              sound.playTap();
              haptics.tap();
              setIsCompanionModalOpen(true);
            }}
            className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-white/95 hover:bg-white text-amber-950 font-black shadow-md border-2 border-amber-300 touch-manipulation cursor-pointer transition transform active:scale-95"
          >
            <span className="text-xl filter drop-shadow">{companionDef.emoji}</span>
            <span className="text-xs md:text-sm font-black hidden sm:inline">{companionProfile.name}</span>
          </button>

          <button
            onClick={() => {
              sound.playTap();
              setIsAudioTestOpen(true);
            }}
            className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-amber-400 hover:bg-amber-500 text-amber-950 text-xs md:text-sm font-black shadow-md border-2 border-amber-200 cursor-pointer touch-manipulation transition transform active:scale-95"
          >
            <Volume2 className="w-4 h-4 animate-bounce" />
          </button>
          
          <PWAInstallButton />
          
          <div
            onPointerDown={handleParentLockPointerDown}
            onPointerUp={handleParentLockPointerUp}
            onPointerLeave={handleParentLockPointerUp}
            className="relative w-10 h-10 rounded-full bg-white/80 hover:bg-white border-2 border-slate-300 text-slate-600 flex items-center justify-center cursor-pointer touch-manipulation shadow-sm"
          >
            {parentHoldProgress > 0 && (
              <svg className="absolute inset-0 w-full h-full -rotate-90 pointer-events-none">
                <circle cx="18" cy="18" r="16" stroke="#6366f1" strokeWidth="3" fill="none" strokeDasharray="100" strokeDashoffset={100 - parentHoldProgress * 100} />
              </svg>
            )}
            <Lock className="w-4 h-4" />
          </div>
        </div>
      </header>

      {friendUnlockBanner && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative z-20 max-w-xl mx-auto w-full my-2 bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 text-white p-3 rounded-2xl shadow-xl flex items-center justify-between border-2 border-emerald-300"
        >
          <div className="flex items-center gap-2">
            <span className="text-2xl animate-bounce">🎁</span>
            <span className="text-xs md:text-sm font-black">{friendUnlockBanner}</span>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={() => {
                sound.playTap();
                setIsCompanionModalOpen(true);
                setFriendUnlockBanner(null);
              }}
              className="px-2.5 py-1 bg-white text-emerald-950 font-black rounded-xl text-xs shadow-xs cursor-pointer active:scale-95"
            >
              استكشف
            </button>
            <button onClick={() => setFriendUnlockBanner(null)} className="p-1 hover:bg-white/20 rounded-full text-white cursor-pointer">
              <X className="w-4 h-4" />
            </button>
          </div>
        </motion.div>
      )}

      <main className="relative z-10 flex-1 flex flex-col items-center justify-center my-2 max-w-xl mx-auto w-full">
        <motion.div
          key={homePrompt}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white/95 border-3 border-amber-300 rounded-3xl p-4 md:p-5 shadow-lg text-center w-full mb-3 flex items-center gap-3"
        >
          <SpeechSpeakerButton textToSpeak={formatDialogue(homePrompt, companionProfile.name, companionDef.title)} size="md" />
          <p className="text-lg md:text-2xl font-black text-amber-950 leading-relaxed text-right flex-1">
            {formatDialogue(homePrompt, companionProfile.name, companionDef.title)}
          </p>
        </motion.div>

        <div className="my-1 flex flex-col items-center">
          <CompanionCharacter
            type={companionProfile.type}
            mood={luluMood}
            size="hero"
            accessory={companionProfile.equippedAccessory} 
            onClick={() => {
              sound.playTap();
              haptics.tap();
              setLuluMood('happy');
              const lovePhrase = formatDialogue("أنا أحبك يا {name}!", companionProfile.name, companionDef.title);
              sound.speak(lovePhrase);
              setTimeout(() => setLuluMood('idle'), 2500);
            }}
          />
        </div>

        <div className="w-full my-2 rounded-3xl bg-white/90 border-2 border-emerald-200 p-3 shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="font-black text-emerald-950 flex items-center gap-1.5"><CheckCircle2 className="w-5 h-5 text-emerald-500" /> تقدم المغامرة</span>
            <span className="text-sm font-black text-emerald-700">{completedStages.length} / {STAGES_LIST.length}</span>
          </div>
          <div className="h-3 rounded-full bg-emerald-100 overflow-hidden">
            <motion.div animate={{ width: `${(completedStages.length / STAGES_LIST.length) * 100}%` }} className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-teal-500" />
          </div>
          <p className="text-xs font-bold text-emerald-800 mt-2 text-center">كل مرحلة مكتملة تمنحك خبرة جديدة!</p>
        </div>

        <div className="w-full my-2">
          <div className="flex items-center justify-between mb-1.5 px-2">
            <span className="text-xs md:text-sm font-bold text-amber-900">بماذا تشعر الآن؟:</span>
          </div>
          <div className="grid grid-cols-4 gap-2">
            {EMOTIONS_CONFIG.map(item => (
              <button
                key={item.type}
                onClick={() => handleSelectEmotion(item.type)}
                className={`h-24 md:h-28 rounded-3xl border-3 flex flex-col items-center justify-center gap-1 shadow-sm transition transform active:scale-90 touch-manipulation cursor-pointer ${
                  item.color
                } ${selectedEmotion === item.type ? `ring-4 ${item.ring} scale-105 shadow-md font-black` : 'hover:opacity-90'}`}
              >
                <span className="text-3xl md:text-4xl filter drop-shadow-sm">{item.emoji}</span>
                <span className="text-xs md:text-sm font-bold text-center leading-tight">{item.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="w-full mt-4 space-y-3">
          <div className="flex items-center justify-between px-2">
            <h3 className="text-base md:text-lg font-black text-amber-950 flex items-center gap-1.5">
              <Sparkles className="w-5 h-5 text-amber-500" />
              <span>مغامراتنا</span>
            </h3>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {STAGES_LIST.map(st => (
              <button
                key={st.id}
                onClick={() => handleStartStage(st.id)}
                className={`relative h-28 md:h-32 rounded-3xl bg-gradient-to-r ${st.bg} p-4 flex items-center justify-between shadow-lg border-3 ${st.border} touch-manipulation cursor-pointer transition transform active:scale-95`}
              >
                {completedStages.includes(st.id) && <span className="absolute top-2 left-2 flex items-center gap-1 rounded-full bg-white/90 text-emerald-700 px-2 py-1 text-[10px] font-black"><CheckCircle2 className="w-3.5 h-3.5" /> مكتملة</span>}
                <div className="text-right flex-1 pr-2">
                  <span className="text-lg md:text-xl font-black block leading-tight">
                    {st.title}
                  </span>
                  <span className="text-xs md:text-sm font-bold opacity-90 block mt-1">
                    {st.tagline}
                  </span>
                </div>
                <div className="w-12 h-12 md:w-16 md:h-16 rounded-2xl bg-white/20 flex items-center justify-center text-3xl shadow-inner shrink-0">
                  {st.emoji}
                </div>
              </button>
            ))}
          </div>
        </div>
      </main>

      <CompanionSelectionModal
        isOpen={isCompanionModalOpen}
        onClose={() => setIsCompanionModalOpen(false)}
        initialType={companionProfile.type}
        initialName={companionProfile.name}
        isInitialSetup={false}
        onCompanionSelected={(newProf) => {
          setCompanionProfile(newProf);
          setIsCompanionModalOpen(false);
          const greeting = formatDialogue(DIALOGUES.welcome.greeting, newProf.name, COMPANIONS_DATA[newProf.type].title);
          setHomePrompt(greeting);
          sound.speak(`أهلاً بك يا ${newProf.name}!`);
        }}
      />
      
      <BraveryBookModal
        isOpen={isBookOpen}
        onClose={() => setIsBookOpen(false)}
        stars={stars}
      />
      
      <VirtualShopModal
        isOpen={isShopOpen}
        onClose={() => {
          setIsShopOpen(false);
          updateProfileDisplay(); 
        }}
        onProfileUpdated={(newProf) => setCompanionProfile(newProf)}
      />

      <ParentModal
        isOpen={isParentOpen}
        onClose={() => setIsParentOpen(false)}
        onSettingsUpdated={() => setSettings(Storage.getSettings())}
      />

      <AudioTestModal
        isOpen={isAudioTestOpen}
        onClose={() => setIsAudioTestOpen(false)}
      />
    </div>
  );
}

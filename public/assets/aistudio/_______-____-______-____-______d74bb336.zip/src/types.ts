export type EmotionType = 'happy' | 'sad' | 'angry' | 'afraid';

export type CompanionType = 
  | 'lion'
  | 'bunny'
  | 'panda'
  | 'fox'
  | 'elephant'
  | 'owl'
  | 'dino';

export interface CompanionDefinition {
  type: CompanionType;
  title: string;
  defaultName: string;
  emoji: string;
  themeColor: string;
  bgGradient: string;
  desc: string;
  starsRequiredToUnlock: number;
}

export interface CompanionProfile {
  type: CompanionType;
  name: string;
  unlockedTypes: CompanionType[];
  coins: number; 
  ownedAccessories: string[]; 
  equippedAccessory: string | null; 
}

export type StageId = 
  | 'magic_words' 
  | 'hourglass' 
  | 'plan_b' 
  | 'rose_breathing' 
  | 'when_i_cry'
  | 'memory_game'
  | 'zen_bubbles';

export interface StageInfo {
  id: StageId;
  title: string;
  subtitle: string;
  icon: string;
  badgeColor: string;
  accentBg: string;
}

export interface BraveryStar {
  id: string;
  stageId: StageId;
  stageTitle: string;
  timestamp: number;
  sticker: string;
  note: string;
}

export interface ActionLog {
  id: string;
  timestamp: number;
  type: 'crying_chosen' | 'magic_word_used' | 'hourglass_waited' | 'plan_b_picked' | 'rose_completed' | 'hug_received' | 'emotion_selected' | 'game_played';
  stageId?: StageId;
  label: string;
  detail?: string;
}

export type ArgumentType = 'please' | 'promiseAfter' | 'helpFirst' | 'begging' | 'crying' | 'custom';

export interface ArgumentStats {
  please: number;
  promiseAfter: number;
  helpFirst: number;
  begging: number;
  crying: number;
  custom: number;
}

export interface ParentSettings {
  dailyLimitMinutes: number; 
  soundEnabled: boolean;
  voiceRate: number; 
  speechPitch: number; 
  customArgument?: string; 
}

export interface DailyPlayStats {
  dateStr: string; 
  minutesPlayed: number;
  magicWordsCount: number;
  cryingChosenCount: number;
  stagesCompleted: number;
  emotions: EmotionType[];
}

export interface AccessoryItem {
  id: string;
  name: string;
  emoji: string;
  price: number;
  position: 'head' | 'eyes' | 'neck';
}

export const SHOP_ITEMS: AccessoryItem[] = [
  { id: 'crown', name: 'تاج الملك', emoji: '👑', price: 30, position: 'head' },
  { id: 'glasses', name: 'نظارة شمسية', emoji: '🕶️', price: 20, position: 'eyes' },
  { id: 'party_hat', name: 'قبعة الحفلة', emoji: '🎉', price: 15, position: 'head' },
  { id: 'bow_tie', name: 'ربطة عنق', emoji: '🎀', price: 10, position: 'neck' },
];
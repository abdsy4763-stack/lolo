import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, Clock, Sparkles, Smile, ArrowRight, RotateCcw } from 'lucide-react';
import { LuluCharacter, LuluMood } from '../LuluCharacter';
import { MotherCharacter } from '../MotherCharacter';
import { SpeechSpeakerButton } from '../SpeechSpeakerButton';
import { DIALOGUES, formatDialogue } from '../../data/dialogue';
import { sound } from '../../utils/audio';
import { Storage } from '../../utils/storage';
import { COMPANIONS_DATA } from '../CompanionCharacter';

interface StageMagicWordsProps {
  onBack: () => void;
  onEarnStar: (sticker: string, note: string) => void;
}

export const StageMagicWords: React.FC<StageMagicWordsProps> = ({
  onBack,
  onEarnStar,
}) => {
  const companion = Storage.getCompanionProfile();
  const companionDef = COMPANIONS_DATA[companion.type];

  const [luluMood, setLuluMood] = useState<LuluMood>('idle');
  const [motherMood, setMotherMood] = useState<'denying' | 'smiling' | 'givingCookie'>('denying');
  const [currentPrompt, setCurrentPrompt] = useState<string>(
    formatDialogue(DIALOGUES.magicWords.intro, companion.name, companionDef.title)
  );
  const [showCards, setShowCards] = useState(true);
  const [isSuccess, setIsSuccess] = useState(false);
  const [isCryingState, setIsCryingState] = useState(false);

  // تشغيل الصوت عند البدء
  useEffect(() => {
    const speech = formatDialogue(`${DIALOGUES.magicWords.intro} .. ${DIALOGUES.magicWords.instruction}`, companion.name, companionDef.title);
    sound.speak(speech);
  }, []);

  const handleCardClick = (cardType: 'please' | 'promiseAfterDinner' | 'helpFirst' | 'cryingOption') => {
    sound.playTap();

    if (cardType === 'cryingOption') {
      // تفريغ البكاء والاحتواء
      Storage.addLog({
        type: 'crying_chosen',
        stageId: 'magic_words',
        label: 'اختار التعبير عن البكاء',
        detail: 'البكاء عند رفض البسكويتة',
      });

      setLuluMood('crying');
      setIsCryingState(true);
      setShowCards(false);
      setCurrentPrompt(DIALOGUES.magicWords.cryingReaction.luluVoice);
      sound.playWarmHug();

      setTimeout(() => {
        setLuluMood('comforting');
        sound.speak(DIALOGUES.magicWords.cryingReaction.luluVoice, () => {
          setTimeout(() => {
            setLuluMood('idle');
            setIsCryingState(false);
            setShowCards(true);
            setCurrentPrompt("هيا يا بطل، جرب سحر كلامك اللطيف!");
          }, 1500);
        });
      }, 700);

      return;
    }

    // بطاقة مهذبة ناجحة
    const cardData = DIALOGUES.magicWords.cards[cardType];
    Storage.addLog({
      type: 'magic_word_used',
      stageId: 'magic_words',
      label: `استخدم بطاقة: ${cardData.label}`,
      detail: cardData.text,
    });

    setShowCards(false);
    setLuluMood('talking');
    setCurrentPrompt(cardData.voice);

    sound.speak(cardData.voice, () => {
      // رد ماما الإيجابي
      setMotherMood('givingCookie');
      setLuluMood('happy');
      const successVoice = DIALOGUES.magicWords.rewardPraise;
      setCurrentPrompt(successVoice);
      sound.playSuccessChime();

      // ألعاب نارية وكونفيتي
      confetti({
        particleCount: 50,
        spread: 70,
        origin: { y: 0.6 },
      });

      sound.speak(successVoice, () => {
        setIsSuccess(true);
        sound.playTada();
        onEarnStar('🍪', 'بطل الكلمات السحرية');
      });
    });
  };

  const handleReplay = () => {
    sound.playTap();
    setMotherMood('denying');
    setLuluMood('idle');
    setIsSuccess(false);
    setIsCryingState(false);
    setShowCards(true);
    setCurrentPrompt(DIALOGUES.magicWords.intro);
    sound.speak(`${DIALOGUES.magicWords.intro} .. ${DIALOGUES.magicWords.instruction}`);
  };

  return (
    <div className="relative min-h-screen w-full flex flex-col justify-between p-4 md:p-6 bg-gradient-to-b from-amber-100 via-orange-50 to-amber-100 overflow-x-hidden">
      {/* الشريط العلوي */}
      <div className="flex items-center justify-between z-10">
        <button
          onClick={() => {
            sound.playTap();
            onBack();
          }}
          className="flex items-center gap-2 px-5 py-3 rounded-full bg-white/90 hover:bg-white text-amber-950 font-black shadow-md border-2 border-amber-300 text-sm md:text-base touch-manipulation cursor-pointer"
        >
          <ArrowRight className="w-5 h-5" />
          <span>الرئيسية</span>
        </button>

        <div className="flex items-center gap-3">
          <SpeechSpeakerButton textToSpeak={currentPrompt} size="md" />
        </div>
      </div>

      {/* المشهد التفاعلي: لؤلؤ وماما */}
      <div className="flex-1 flex flex-col items-center justify-center my-3 relative">
        {/* فقاعة الحديث الحالية بنص كبير وأيقونة مرافقة واضحة */}
        <motion.div
          key={currentPrompt}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white/95 border-3 border-amber-300 rounded-3xl p-4 md:p-5 shadow-lg text-center max-w-lg w-full mb-4 flex items-center gap-3"
        >
          <span className="text-3xl md:text-4xl shrink-0 filter drop-shadow">
            {motherMood === 'givingCookie' ? '🍪' : isCryingState ? '🥺' : companionDef.emoji}
          </span>
          <p className="text-lg md:text-2xl font-black text-amber-950 leading-relaxed text-right flex-1">
            {currentPrompt}
          </p>
        </motion.div>

        {/* الشخصيات في مشهد واحد */}
        <div className="flex items-end justify-center gap-4 md:gap-10 w-full max-w-lg">
          {/* ماما اللبؤة */}
          <div className="flex flex-col items-center">
            <MotherCharacter mood={motherMood} size="md" />
            <span className="text-xs font-bold text-amber-900 mt-1">ماما الحبيبة</span>
          </div>

          {/* بسكويتة متألقة في المنتصف */}
          <div className="flex flex-col items-center mb-6">
            <motion.div
              animate={{ rotate: [0, 5, -5, 0], scale: [1, 1.06, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="text-4xl md:text-5xl filter drop-shadow-md"
            >
              🍪
            </motion.div>
          </div>

          {/* رفيق الطفل المختار */}
          <div className="flex flex-col items-center">
            <LuluCharacter mood={luluMood} size="md" />
            <span className="text-xs font-bold text-amber-900 mt-1">{companion.name}</span>
          </div>
        </div>
      </div>

      {/* البطاقات الأربعة التفاعلية الضخمة (لا تقل عن 120px) */}
      <div className="w-full max-w-xl mx-auto z-10">
        <AnimatePresence mode="wait">
          {showCards && (
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="grid grid-cols-2 gap-3 md:gap-4"
            >
              {/* بطاقة 1: من فضلك */}
              <button
                onClick={() => handleCardClick('please')}
                className="h-32 md:h-36 rounded-3xl bg-emerald-500 hover:bg-emerald-600 active:bg-emerald-700 text-white p-3 flex flex-col items-center justify-center gap-2 shadow-lg border-4 border-emerald-300 touch-manipulation cursor-pointer transition transform active:scale-95"
              >
                <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center text-2xl">
                  🤲
                </div>
                <span className="text-base md:text-lg font-black leading-tight text-center">
                  {DIALOGUES.magicWords.cards.please.label}
                </span>
              </button>

              {/* بطاقة 2: بعد العشاء؟ أعدك! */}
              <button
                onClick={() => handleCardClick('promiseAfterDinner')}
                className="h-32 md:h-36 rounded-3xl bg-blue-500 hover:bg-blue-600 active:bg-blue-700 text-white p-3 flex flex-col items-center justify-center gap-2 shadow-lg border-4 border-blue-300 touch-manipulation cursor-pointer transition transform active:scale-95"
              >
                <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center text-2xl">
                  ⏰
                </div>
                <span className="text-base md:text-lg font-black leading-tight text-center">
                  {DIALOGUES.magicWords.cards.promiseAfterDinner.label}
                </span>
              </button>

              {/* بطاقة 3: أساعدكِ أولاً */}
              <button
                onClick={() => handleCardClick('helpFirst')}
                className="h-32 md:h-36 rounded-3xl bg-purple-500 hover:bg-purple-600 active:bg-purple-700 text-white p-3 flex flex-col items-center justify-center gap-2 shadow-lg border-4 border-purple-300 touch-manipulation cursor-pointer transition transform active:scale-95"
              >
                <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center text-2xl">
                  ✨
                </div>
                <span className="text-base md:text-lg font-black leading-tight text-center">
                  {DIALOGUES.magicWords.cards.helpFirst.label}
                </span>
              </button>

              {/* بطاقة 4: البكاء والتعبير عن الحزن (تحتضنه دون عقاب) */}
              <button
                onClick={() => handleCardClick('cryingOption')}
                className="h-32 md:h-36 rounded-3xl bg-amber-400 hover:bg-amber-500 active:bg-amber-600 text-amber-950 p-3 flex flex-col items-center justify-center gap-2 shadow-lg border-4 border-amber-200 touch-manipulation cursor-pointer transition transform active:scale-95"
              >
                <div className="w-12 h-12 rounded-2xl bg-white/40 flex items-center justify-center text-2xl">
                  🥺
                </div>
                <span className="text-base md:text-lg font-black leading-tight text-center">
                  {DIALOGUES.magicWords.cards.cryingOption.label}
                </span>
              </button>
            </motion.div>
          )}

          {/* حالة احتضان البكاء */}
          {isCryingState && (
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="p-5 bg-amber-200/90 border-3 border-amber-400 rounded-3xl text-center shadow-lg"
            >
              <div className="text-3xl mb-2">🤗💛</div>
              <p className="text-base md:text-lg font-black text-amber-950">
                {DIALOGUES.magicWords.cryingReaction.luluActionText}
              </p>
            </motion.div>
          )}

          {/* شاشة النجاح والنجمة */}
          {isSuccess && (
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="p-5 bg-emerald-500 border-4 border-emerald-300 text-white rounded-3xl text-center shadow-2xl flex flex-col items-center gap-3"
            >
              <div className="text-4xl animate-bounce">⭐ 🍪 ⭐</div>
              <p className="text-xl md:text-2xl font-black">
                {DIALOGUES.magicWords.rewardPraise}
              </p>
              <div className="flex gap-3 mt-1">
                <button
                  onClick={handleReplay}
                  className="flex items-center gap-2 px-6 py-3 rounded-full bg-white text-emerald-800 font-black text-base shadow hover:bg-emerald-50 active:scale-95 touch-manipulation cursor-pointer"
                >
                  <RotateCcw className="w-5 h-5" />
                  <span>العب مجدداً</span>
                </button>
                <button
                  onClick={onBack}
                  className="px-6 py-3 rounded-full bg-emerald-700 hover:bg-emerald-800 text-white font-black text-base shadow active:scale-95 touch-manipulation cursor-pointer"
                >
                  المغامرة التالية
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

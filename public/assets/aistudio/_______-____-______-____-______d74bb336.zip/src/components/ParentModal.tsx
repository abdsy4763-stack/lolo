import React, { useState, useEffect } from 'react';
import { X, Lock, CheckCircle, BarChart3, Clock, Sparkles, BookOpen, AlertCircle, RefreshCw, Volume2 } from 'lucide-react';
import { Storage } from '../utils/storage';
import { ParentSettings, DailyPlayStats, ActionLog } from '../types';
import { DIALOGUES } from '../data/dialogue';
import { sound, audioManager, AudioDiagnostics } from '../utils/audio';

interface ParentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSettingsUpdated: () => void;
}

export const ParentModal: React.FC<ParentModalProps> = ({
  isOpen,
  onClose,
  onSettingsUpdated,
}) => {
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [mathQuestion, setMathQuestion] = useState({ a: 0, b: 0, answer: 0 });
  const [parentAnswer, setParentAnswer] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const [settings, setSettings] = useState<ParentSettings>(Storage.getSettings());
  const [stats, setStats] = useState<DailyPlayStats[]>([]);
  const [logs, setLogs] = useState<ActionLog[]>([]);
  const [todaySeconds, setTodaySeconds] = useState(0);
  const [diagnostics, setDiagnostics] = useState<AudioDiagnostics>(() => audioManager.getDiagnostics());
  const [isTestingAudio, setIsTestingAudio] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setStats(Storage.getDailyStats());
      setLogs(Storage.getLogs());
      setSettings(Storage.getSettings());
      setTodaySeconds(Storage.getTodayPlaySeconds());
      setDiagnostics(audioManager.getDiagnostics());
      generateMathProblem();
    } else {
      setIsUnlocked(false);
      setParentAnswer('');
      setErrorMsg('');
    }
  }, [isOpen]);

  const generateMathProblem = () => {
    // أرقام أصعب للضرب (بين 3 و 9) لضمان عدم تجاوز الأطفال لها بسهولة
    const a = Math.floor(Math.random() * 7) + 3;
    const b = Math.floor(Math.random() * 7) + 3;
    setMathQuestion({ a, b, answer: a * b });
  };

  const refreshDiagnostics = () => {
    setDiagnostics(audioManager.getDiagnostics());
  };

  const handleVerifyMath = (e: React.FormEvent) => {
    e.preventDefault();
    if (parseInt(parentAnswer, 10) === mathQuestion.answer) {
      setIsUnlocked(true);
      setErrorMsg('');
      sound.playSuccessChime();
      refreshDiagnostics();
    } else {
      setErrorMsg('إجابة خاطئة، حاول مجدداً.');
      setParentAnswer('');
    }
  };

  const handleTimeLimitChange = (minutes: number) => {
    sound.playTap();
    const updated = Storage.saveSettings({ dailyLimitMinutes: minutes });
    setSettings(updated);
    onSettingsUpdated();
  };

  const handleResetPlaytime = () => {
    sound.playTap();
    Storage.resetTodayPlaytime();
    setTodaySeconds(0);
    onSettingsUpdated();
  };

  const handleSeedDemoData = () => {
    sound.playTap();
    Storage.seedDemoStatsForParents();
    setStats(Storage.getDailyStats());
  };

  const handleTestAudio = () => {
    setIsTestingAudio(true);
    sound.playTap();
    audioManager.testAudio(() => {
      setIsTestingAudio(false);
      refreshDiagnostics();
    });
  };

  const handleReloadVoices = () => {
    sound.playTap();
    audioManager.loadVoices();
    refreshDiagnostics();
  };

  const totalMagicWords = stats.reduce((acc, curr) => acc + (curr.magicWordsCount || 0), 0);
  const totalCryingChosen = stats.reduce((acc, curr) => acc + (curr.cryingChosenCount || 0), 0);
  const totalStagesCompleted = stats.reduce((acc, curr) => acc + (curr.stagesCompleted || 0), 0);
  const uniqueStagesCompleted = Storage.getCompletedStageIds().length;
  const totalDays = stats.length || 1;

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-4 bg-slate-900/80 backdrop-blur-md">
      <div className="relative w-full max-w-2xl max-h-[90vh] bg-white rounded-3xl shadow-2xl p-5 md:p-6 flex flex-col overflow-hidden text-right border-4 border-slate-200">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-indigo-100 text-indigo-700 flex items-center justify-center">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl md:text-2xl font-bold text-slate-800">بوابة الوالدين</h2>
              <p className="text-xs text-slate-500 font-medium">إعدادات ومتابعة تطور طفلك</p>
            </div>
          </div>
          <button
            onClick={() => {
              sound.playTap();
              onClose();
            }}
            className="w-10 h-10 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {!isUnlocked ? (
          <div className="my-auto py-8 text-center max-w-sm mx-auto">
            <div className="w-16 h-16 bg-amber-100 text-amber-600 rounded-3xl flex items-center justify-center mx-auto mb-4">
              <Lock className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-bold text-slate-800 mb-1">المنطقة الخاصة بالكبار</h3>
            <p className="text-sm text-slate-600 mb-5">للتحقق من أنك ولي الأمر، يرجى حل العملية التالية:</p>
            <form onSubmit={handleVerifyMath} className="space-y-4">
              <div className="text-3xl font-black tracking-wider text-indigo-600 bg-indigo-50 py-3 rounded-2xl border border-indigo-200">
                {mathQuestion.a} × {mathQuestion.b} = ?
              </div>
              <input
                type="number"
                pattern="[0-9]*"
                inputMode="numeric"
                value={parentAnswer}
                onChange={e => setParentAnswer(e.target.value)}
                placeholder="أدخل الناتج هنا"
                autoFocus
                className="w-full text-center text-xl font-bold p-3 border-2 border-slate-300 rounded-2xl focus:border-indigo-500 focus:outline-none"
              />
              {errorMsg && <p className="text-rose-600 text-xs font-bold">{errorMsg}</p>}
              <button
                type="submit"
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-bold rounded-2xl shadow transition cursor-pointer"
              >
                دخول
              </button>
            </form>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto space-y-6 pr-1 pl-1 py-4">
            
            <div className="p-4 bg-indigo-50/80 rounded-2xl border border-indigo-200 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-slate-800 flex items-center gap-1.5 text-sm md:text-base">
                  <Volume2 className="w-5 h-5 text-indigo-600" />
                  <span>فحص نظام النطق (Audio Diagnostics)</span>
                </h4>
                <button
                  onClick={handleTestAudio}
                  disabled={isTestingAudio}
                  className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-xs flex items-center gap-1.5 cursor-pointer touch-manipulation"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>{isTestingAudio ? 'جاري الفحص...' : 'اختبار الصوت'}</span>
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                <div className="p-2.5 bg-white rounded-xl border border-slate-200 flex items-center justify-between">
                  <span className="text-slate-600 font-medium">حالة المحرك (AudioContext):</span>
                  <span
                    className={`font-bold px-2 py-0.5 rounded-md ${
                      diagnostics.audioContextState === 'running'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {diagnostics.audioContextState === 'running' ? 'متصل (Running)' : diagnostics.audioContextState}
                  </span>
                </div>
                <div className="p-2.5 bg-white rounded-xl border border-slate-200 flex items-center justify-between">
                  <span className="text-slate-600 font-medium">إجمالي الأصوات المثبتة:</span>
                  <span className="font-bold text-slate-800 bg-slate-100 px-2 py-0.5 rounded-md">
                    {diagnostics.totalVoicesCount} صوت
                  </span>
                </div>
                <div className="p-2.5 bg-white rounded-xl border border-slate-200 col-span-1 sm:col-span-2">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-slate-600 font-medium">الصوت العربي الافتراضي:</span>
                    <button
                      onClick={handleReloadVoices}
                      className="text-[11px] text-indigo-600 font-bold hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>تحديث القائمة</span>
                    </button>
                  </div>
                  {diagnostics.hasArabicVoice ? (
                    <div className="flex items-center gap-1.5 text-emerald-700 font-bold">
                      <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span className="truncate">{diagnostics.selectedVoiceName}</span>
                    </div>
                  ) : (
                    <div className="p-2.5 bg-amber-50 border border-amber-300 rounded-lg text-amber-900 text-xs leading-relaxed space-y-1">
                      <div className="flex items-center gap-1 font-bold text-amber-800">
                        <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                        <span>لم يتم العثور على صوت عربي!</span>
                      </div>
                      <p className="text-[11px] text-slate-600">
                        يرجى التأكد من تفعيل "تحويل النص إلى كلام باللغة العربية (Arabic TTS)" في إعدادات جهازك.
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-200 text-center">
                <span className="text-2xl font-black text-emerald-700 block">{totalMagicWords}</span>
                <span className="text-xs text-emerald-900 font-bold">كلمات سحرية</span>
              </div>
              <div className="p-3 bg-amber-50 rounded-2xl border border-amber-200 text-center">
                <span className="text-2xl font-black text-amber-700 block">{totalCryingChosen}</span>
                <span className="text-xs text-amber-900 font-bold">نوبات بكاء</span>
              </div>
              <div className="p-3 bg-blue-50 rounded-2xl border border-blue-200 text-center">
                <span className="text-2xl font-black text-blue-700 block">{totalStagesCompleted}</span>
                <span className="text-xs text-blue-900 font-bold">مراحل مكتملة</span>
              </div>
              <div className="p-3 bg-teal-50 rounded-2xl border border-teal-200 text-center">
                <span className="text-2xl font-black text-teal-700 block">{uniqueStagesCompleted}/7</span>
                <span className="text-xs text-teal-900 font-bold">مراحل مختلفة</span>
              </div>
              <div className="p-3 bg-purple-50 rounded-2xl border border-purple-200 text-center">
                <span className="text-2xl font-black text-purple-700 block">{totalDays}</span>
                <span className="text-xs text-purple-900 font-bold">أيام النشاط</span>
              </div>
            </div>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-bold text-slate-800 flex items-center gap-1.5 text-sm md:text-base">
                  <BarChart3 className="w-5 h-5 text-indigo-600" />
                  <span>تطور سلوك الطلب (تحليل إجمالي)</span>
                </h4>
                {stats.length < 2 && (
                  <button
                    onClick={handleSeedDemoData}
                    className="text-[11px] text-indigo-600 font-bold hover:underline"
                  >
                    توليد بيانات تجريبية
                  </button>
                )}
              </div>
              {totalMagicWords + totalCryingChosen === 0 ? (
                <p className="text-xs text-slate-500 py-3 text-center">
                  لا توجد بيانات كافية بعد. دع طفلك يجرب اللعبة بضع مرات!
                </p>
              ) : (
                <div>
                  <div className="h-6 w-full rounded-full bg-slate-200 overflow-hidden flex">
                    <div
                      style={{
                        width: `${Math.round((totalMagicWords / (totalMagicWords + totalCryingChosen || 1)) * 100)}%`,
                      }}
                      className="bg-emerald-500 h-full flex items-center justify-center text-[10px] text-white font-bold transition-all duration-500"
                    >
                      {totalMagicWords > 0 && `${Math.round((totalMagicWords / (totalMagicWords + totalCryingChosen || 1)) * 100)}%`}
                    </div>
                    <div
                      style={{
                        width: `${Math.round((totalCryingChosen / (totalMagicWords + totalCryingChosen || 1)) * 100)}%`,
                      }}
                      className="bg-amber-400 h-full flex items-center justify-center text-[10px] text-amber-950 font-bold transition-all duration-500"
                    >
                      {totalCryingChosen > 0 && `${Math.round((totalCryingChosen / (totalMagicWords + totalCryingChosen || 1)) * 100)}%`}
                    </div>
                  </div>
                  <div className="flex justify-between items-center mt-2 text-xs text-slate-600 font-medium">
                    <span className="flex items-center gap-1">
                      <span className="w-3 h-3 rounded-full bg-emerald-500 inline-block" />
                      استخدام الحوار والنقاش ({totalMagicWords})
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="w-3 h-3 rounded-full bg-amber-400 inline-block" />
                      اختيار البكاء والغضب ({totalCryingChosen})
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-2">
                    * ارتفاع اللون الأخضر يعني تطوراً ممتازاً في مهارات التفاوض والتعبير العاطفي لدى الطفل.
                  </p>
                </div>
              )}
            </div>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-slate-800 flex items-center gap-1.5 text-sm md:text-base">
                  <Clock className="w-5 h-5 text-indigo-600" />
                  <span>الحد الزمني اليومي للعب</span>
                </h4>
                <span className="text-xs font-bold text-indigo-700 bg-indigo-100 px-2.5 py-1 rounded-full">
                  المتبقي اليوم: {Math.max(0, settings.dailyLimitMinutes - Math.round(todaySeconds / 60))} دقيقة
                </span>
              </div>
              <p className="text-xs text-slate-600 leading-normal">
                اختر المدة المسموح بها يومياً. بعد انتهاء الوقت، سيذهب "لؤلؤ" للنوم ولن يتمكن الطفل من اللعب حتى اليوم التالي.
              </p>
              <div className="flex flex-wrap gap-2">
                {[10, 15, 20, 30, 999].map(mins => (
                  <button
                    key={mins}
                    onClick={() => handleTimeLimitChange(mins)}
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold transition border cursor-pointer ${
                      settings.dailyLimitMinutes === mins
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow'
                        : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                    }`}
                  >
                    {mins === 999 ? 'بدون حد (مفتوح)' : `${mins} دقيقة`}
                  </button>
                ))}
              </div>
              <button
                onClick={handleResetPlaytime}
                className="flex items-center gap-1.5 text-xs text-rose-600 font-bold hover:underline pt-1 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>تصفير وقت اللعب لليوم</span>
              </button>
            </div>

            <div className="p-4 bg-amber-50/60 rounded-2xl border border-amber-200 space-y-3">
              <h4 className="font-bold text-amber-950 flex items-center gap-1.5 text-sm md:text-base">
                <BookOpen className="w-5 h-5 text-amber-700" />
                <span>نصائح تربوية لكِ</span>
              </h4>
              <div className="space-y-2.5">
                {DIALOGUES.parentTips.map((tipItem, idx) => (
                  <div key={idx} className="bg-white p-3 rounded-xl border border-amber-200/80 shadow-xs">
                    <h5 className="text-xs font-black text-amber-900 mb-1">{idx + 1}. {tipItem.title}</h5>
                    <p className="text-xs text-slate-700 leading-relaxed">{tipItem.tip}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-2 p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-xs text-emerald-900 font-medium">
              <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>البيانات تبقى 100% على جهازك، لا يتم إرسال أي شيء للإنترنت.</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
